<!-- HOME START-->
<section class="bg-half" style="background-image: url('assets/images/home/bg-pages.jpg');">
            <div class="bg-overlay"></div>
            <div class="home-center">
                <div class="home-desc-center">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-12">
                                <div class="page-next-level text-white">
                                    <h4 class="text-uppercase">Đây là Breadrum</h4>
                                    <div class="page-next"> <a href="">Home</a> <i class="mdi mdi-chevron-right"></i> &nbsp;<a href="#">Pages</a> <i class="mdi mdi-chevron-right"></i> &nbsp;<span>Breadrum</span> </div>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- HOME END--> 