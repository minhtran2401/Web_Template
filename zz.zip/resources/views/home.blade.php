


<?php
     $tem = DB::table('template')
    ->select(DB::raw('count(*) as tem_count, id_temp'))
    ->where('id_temp', '<>', 0)
    ->groupBy('id_temp')
    ->get();

    $type = DB::table('template_type')
    ->select(DB::raw('count(*) as type_count, id_type'))
    ->where('id_type', '<>', 0)
    ->groupBy('id_type')
    ->get();

?>
        @yield('header')

        <section class="section-two bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <div class="feature">
                            <div class="fe-icon">
                                <i class="fas fa-globe float-left"></i>
                            </div>
                            <div class="fe-head">
                                <h4>Hign Performance</h4>
                                <p class="text-muted mb-0">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled</p>
                                <span>01.</span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="feature">
                            <div class="fe-icon">
                                <i class="fas fa-hands-helping float-left"></i>
                            </div>
                            <div class="fe-head">
                                <h4>Trusted Partners</h4>
                                <p class="text-muted mb-0">It is a long established fact that a reader will be distracted by the readable content of at its layout.</p>
                                <span>02.</span>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="feature">
                            <div class="fe-icon">
                                <i class="fas fa-chart-line float-left"></i>
                            </div>
                            <div class="fe-head">
                                <h4>Well Organized</h4>
                                <p class="text-muted mb-0">Many desktop publishing packages and web page editors now use Lorem Ipsum as their text, and a search.</p>
                                <span>03.</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ABOUT US START -->
        <section class="section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5 col-md-6">
                        <div class="about-pic">
                            <img src="assets/images/about/about-pic.jpg" class="img-fluid" alt="">
                            <div class="watch-video about-video text-center">
                                <div class="project-video">
                                    <div class="project-video-border">
                                        <div class="project-video-icon">
                                            <a href="https://www.youtube.com/watch?v=3rTyi3oEziU" class="video-play-icon text-white text-center" title="Watch Now"><i class="mdi mdi-play play-icon play h2 mb-0 mx-auto"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7 col-md-6">
                        <div class="about-section ml-lg-3 mt-sm-30">
                            <h4 class="text-uppercase">We're knowledgeable about making benefits higher</h4>
                            <div class="spacer-15"></div>
                            <p class="text-muted">Why I say old chap that is, spiffing tomfoolery lost the plot plastered starkers tosser, say no biggie brolly bleeding super. The full monty Elizabeth nice one quaint butty give us a bell easy peasy gutted mate smashing, crikey cracking goal bobby James Bond knackered spiffing young delinquent down the pub bodge, bugger all mate old cor blimey guvnor what a load of rubbish.!</p>
                            <div class="mt-30">
                                <a href="#" class="btn btn-custom">Our Mission</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- ABOUT US END -->

        <!-- SERVICES START -->
        <section class="section bg-light"> 
            <div class="container"> 
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-12">
                        <div class="section-title text-center">
                            <h3>Our Services</h3>
                            <div class="spacer-15"></div>
                            <p class="text-muted mb-0">Donec sodales sagittis magna. Excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.</p>
                            <div class="spacer-30"></div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="types-of-service mt-30 p-20">
                            <div class="service-icon text-custom">
                                <i class="fas fa-chalkboard-teacher float-left mb-0"></i>
                            </div>
                            <div class="service-head">
                                <h4>Fast processing</h4>
                                <p class="text-muted mb-0">There are many variations of passages of Ipsum available alteration in some form.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6">
                        <div class="types-of-service mt-30 p-20">
                            <div class="service-icon text-custom">
                                <i class="fas fa-hand-holding-heart float-left mb-0"></i>
                            </div>
                            <div class="service-head">
                                <h4>Premium Sliders</h4>
                                <p class="text-muted mb-0">Contrary to popular belief, it has roots it has roots in a piece of classical in a piece of classical Latin literature.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="types-of-service mt-30 p-20">
                            <div class="service-icon text-custom">
                                <i class="fas fa-wrench float-left mb-0"></i>
                            </div>
                            <div class="service-head">
                                <h4>Free Support</h4>
                                <p class="text-muted mb-0">No one rejects, dislikes, or avoids pleasure itself, because it has roots in a piece of classical it is pleasure.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="types-of-service mt-30 p-20">
                            <div class="service-icon text-custom">
                                <i class="fab fa-digital-ocean float-left mb-0"></i>
                            </div>
                            <div class="service-head">
                                <h4>Clean Modern Code</h4>
                                <p class="text-muted mb-0">Nam libero tempore, cum soluta nobis est eligendi optio it has roots in a cumque nihil impedit quo minus.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="types-of-service mt-30 p-20">
                            <div class="service-icon text-custom">
                                <i class="fas fa-layer-group float-left mb-0"></i>
                            </div>
                            <div class="service-head">
                                <h4>Flexible Layouts</h4>
                                <p class="text-muted mb-0">On the other hand, we indignation and dislike men it has roots in a piece of are so beguiled and demoralized.</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 col-md-6">
                        <div class="types-of-service mt-30 p-20">
                            <div class="service-icon text-custom">
                                <i class="fab fa-sketch float-left mb-0"></i>
                            </div>
                            <div class="service-head">
                                <h4>Modern Design</h4>
                                <p class="text-muted mb-0">Nor again is there anyone who loves or pursues it has roots in a piece of classical to obtain pain of itself.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- SERVICES END -->

        <!-- CTA START -->
        <section class="section bg-cta-img">
            <div class="bg-overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="cta-heading text-center text-white">
                            <h3>Trending ideas and inventions always make us feel proud</h3>
                            <div class="spacer-15"></div>
                            <p class="mx-auto cta_details text-white-50">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="watch-video text-center">
                            <div class="project-video">
                                <div class="project-video-border">
                                    <div class="project-video-icon">
                                        <a href="https://www.youtube.com/watch?v=ToizAqT4Fw0" class="video-play-icon text-white text-center" title="Watch Now"><i class="mdi mdi-play play-icon play h2 mb-0 mx-auto"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- CTA END -->

        <!-- WORK START -->
        @include('tempmoitheoloai')
        <!-- WORK END -->

        <!-- TESTIMONIAL START-->
        <section class="section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-12">
                        <div class="section-title text-center">
                            <h3>Happy Client's Says</h3>
                            <div class="spacer-15"></div>
                            <p class="text-muted mb-0">Donec sodales sagittis magna. Excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.</p>
                            <div class="spacer-30"></div>
                        </div>
                    </div>
                </div>

                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div id="owl-demo" class="owl-carousel">
                            <div class="testi-box">
                                <div class="text-center">
                                    <div class="client-drow mt-30 p-2">
                                        <img src="assets/images/client/img-1.jpg" alt="" class="img-fluid img-thumbnail testi-img rounded-circle">
                                        <div class="testi-content mt-2">
                                            <div class="client-name">
                                                <h4>Harvey Rose</h4>
                                                <p class="mb-0">Founder</p>
                                            </div>
                                            <p class="user-review text-center text-muted"><i class="mdi mdi-format-quote-open"></i>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
                                            <div class="review-star">
                                                <ul class="list-unstyled">
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star-half-alt"></i></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="testi-box">
                                <div class="text-center">
                                    <div class="client-drow mt-30 p-2">
                                        <img src="assets/images/client/img-2.jpg" alt="" class="img-fluid img-thumbnail testi-img rounded-circle">
                                        <div class="testi-content mt-2">
                                            <div class="client-name">
                                                <h4>Norman Watson</h4>
                                                <p class="mb-0">C.E.O</p>
                                            </div>
                                            <p class="user-review text-center text-muted"><i class="mdi mdi-format-quote-open"></i>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt</p>
                                            <div class="review-star">
                                                <ul class="list-unstyled">
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star-half-alt"></i></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="testi-box">
                                <div class="text-center">
                                    <div class="client-drow mt-30 p-2">
                                        <img src="assets/images/client/img-3.jpg" alt="" class="img-fluid img-thumbnail testi-img rounded-circle">
                                        <div class="testi-content mt-2">
                                            <div class="client-name">
                                                <h4>Nancy Nunez</h4>
                                                <p class="mb-0">Adviser</p>
                                            </div>
                                            <p class="user-review text-center text-muted"><i class="mdi mdi-format-quote-open"></i>Quisque eget turpis volutpat, posuere ipsum sed, hendrerit nisi. Mauris posuere ipsum sed, hendrerit nisi. Mauris ac placerat dui. Fusce venenatis porta ipsum, et aliquet lacus posuere sed. Etiam efficitur a ligula at condimentum.</p>
                                            <div class="review-star">
                                                <ul class="list-unstyled">
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star"></i></li>
                                                    <li class="list-inline-item"><i class="fas fa-star-half-alt"></i></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- TESTIMONIAL END -->

        

        <!-- COUNTER START -->
        <section class="section bg-counter">
            <div class="bg-overlay"></div>
            <div class="container">
                <div class="row" id="counter">

                    <div class="col-lg-3 col-md-3">
                        <div class="text-center counter-funfact p-4 mt-3 text-white">
                            <i class="pe-7s-box2 counter-icon"></i>
                            <h2 class="counter-value" data-count="640">   {{$type->count()}}</h2>
                            <p class="counter-name mb-0">Loại Khác Nhau</p>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-3">
                        <div class="text-center counter-funfact left-border  p-4 mt-3 text-white">
                            <i class="pe-7s-note2 counter-icon"></i>
                            
                            <h2 class="counter-value" data-count="654">
                               {{$tem->count()}}
                              </h2>
                            <p class="counter-name mb-0">Giao Diện</p>
                        </div>
                    </div>
                    
                    <div class="col-lg-3 col-md-3">
                        <div class="text-center counter-funfact left-border p-4 mt-3 text-white">
                            <i class="pe-7s-download counter-icon"></i>
                            <h2 class="counter-value" data-count="238">356</h2>
                            <p class="counter-name mb-0">Lượt Tải Xuống</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3">
                        <div class="text-center counter-funfact left-border p-4 mt-3 text-white">
                            <i class="pe-7s-global counter-icon"></i>                      
                            <h2 class="counter-value" data-count="532">1459</h2>
                            <p class="counter-name mb-0">Lượt Truy Cập</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- COUNTER END -->

        <!-- TEAM START -->
        <section class="section bg-light">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-12">
                        <div class="section-title text-center">
                            <h3>Our Team</h3>
                            <div class="spacer-15"></div>
                            <p class="text-muted mb-0">Donec sodales sagittis magna. Excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi.</p>
                            <div class="spacer-30"></div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-4 col-md-6">
                        <div class="team-box mt-30">
                            <div class="team-box-img">
                                <img src="assets/images/team/image-1.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="team-info text-center">
                                <h3 class="mb-0">Shophie Cassidy</h3>
                                <small class="text-muted">CEO/Founder</small>
                                <div class="text-center mt-3">
                                    <ul class="list-unstyled social-icon mb-0">
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-apple"></i></a></li>
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="team-box mt-30">
                            <div class="team-box-img">
                                <img src="assets/images/team/image-2.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="team-info text-center">
                                <h3 class="mb-0">Steve Mitchell</h3>
                                <small class="text-muted">Project Manager</small>
                                <div class="text-center mt-3">
                                    <ul class="list-unstyled social-icon mb-0">
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-apple"></i></a></li>
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="team-box mt-30">
                            <div class="team-box-img">
                                <img src="assets/images/team/image-3.jpg" alt="" class="img-fluid">
                            </div>
                            <div class="team-info text-center">
                                <h3 class="mb-0">William Beck</h3>
                                <small class="text-muted">Web Designer</small>
                                <div class="text-center mt-3">
                                    <ul class="list-unstyled social-icon mb-0">
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-apple"></i></a></li>
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
                                        <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
        <!-- TEAM END -->

        

        <!-- PARTNER START -->
        <section class="section-two bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 p-0">
                        <div class="slider autoplay">
                            <div><img src="assets/images/client/partner-1.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                            <div><img src="assets/images/client/partner-2.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                            <div><img src="assets/images/client/partner-3.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                            <div><img src="assets/images/client/partner-4.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                            <div><img src="assets/images/client/partner-5.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                            <div><img src="assets/images/client/partner-1.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                            <div><img src="assets/images/client/partner-2.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                            <div><img src="assets/images/client/partner-3.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                            <div><img src="assets/images/client/partner-4.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                            <div><img src="assets/images/client/partner-5.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- PARTNER END -->

        <!-- CONTACT END -->
        <section class="section-two bg-custom">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8 col-md-12">
                        <div class="text-center">
                            <h5 class="text-light text-uppercase font-22">Do You Want To Work With Alita ?</h5>
                            <div class="spacer-30"></div>
                            <div>
                                <a href="contact" class="btn btn-custom-white">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- CONTACT END -->

        @yield('footer')

