@extends('admin.layoutadmin')
@section('pagetitle', 'QUẢN LÍ LOẠI TEMPLATE ')
@section('main')
    @include('admin/templatetype/looptype')
@endsection