@extends('admin.layoutadmin')
@section('pagetitle', 'QUẢN LÍ TEMPLATE ')
@section('main')
    @include('admin/template/looptemp')
@endsection