@section('header')
@section('pagetitle', 'LOGO | Website download template hàng đầu VN')
    @include('header')


    @include('slide')
    @include('menu')
@endsection
@extends("home")
@section('footer')
    @include('footer')
@endsection