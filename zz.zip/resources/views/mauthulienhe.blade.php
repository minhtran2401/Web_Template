<h4>Thư liên hệ từ người xem:</h4>
<p>Tên: {{$name}} </p>
<p>Số Điện Thoại: {{$phone}} </p>
<p>Email: {{$email}}</p>
<p>Tiêu Đề: {{$title}} </p>
<div>Nội dung:<br/>
    {{$content}}
</div>
