
<?php $__env->startSection('pagetitle', 'QUẢN LÍ LOẠI TEMPLATE '); ?>
<?php $__env->startSection('main'); ?>
    <?php echo $__env->make('admin/templatetype/looptype', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layoutadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web_Template\resources\views/admin/templatetype/index.blade.php ENDPATH**/ ?>