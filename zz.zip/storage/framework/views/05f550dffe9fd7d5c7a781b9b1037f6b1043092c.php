<aside id="page-sidebar" class="collapse navbar-collapse navbar-main-collapse">
    <!-- Sidebar search -->
    <form id="sidebar-search" action="page_search_results.html" method="post">
        <div class="input-group">
            <input type="text" id="sidebar-search-term" name="sidebar-search-term" placeholder="Search..">
            <button><i class="fa fa-search"></i></button>
        </div>
    </form>
    <!-- END Sidebar search -->
  
    <!-- Primary Navigation -->
    <nav id="primary-nav">
        <ul>
            <li>
                <a href="http://localhost/LARAVEL/ASM2/public/dashboard" class="active"><i class="fa fa-home"></i>Dashboard</a>
            </li>
  
            <li>
                <a href=""><i class="fa fa-th-list"></i>Thể Loại</a>
                <ul>
                    <li>
                        <a href=""><i class="fa fa-file-text"></i>Thể Loại</a>
                    </li>
                    <li>
                        <a href=""><i class="fa fa-file-text"></i>Thêm Thể Loại</a>
                    </li>
                   
                </ul>
            </li>
  
            <li>
              <a href=""><i class="fa fa-cubes"></i>Loại Tin</a>
              <ul>
                  <li>
                      <a href=""><i class="fa fa-file-text"></i>Loại Tin</a>
                  </li>
                  <li>
                      <a href=""><i class="fa fa-file-text"></i>Thêm Loại Tin</a>
                  </li>
                 
              </ul>
          </li>
  
          <li>
            <a href=""><i class="fa fa-pencil-square"></i>Tin Tức</a>
            <ul>
                <li>
                    <a href=""><i class="fa fa-file-text"></i>Tin Tức</a>
                </li>
                <li>
                    <a href=""><i class="fa fa-file-text"></i>Thêm Tin Mới</a>
                </li>
               
            </ul>
        </li>
  
        <li>
          <a href=""><i class="gi gi-notes          "></i>Ý Kiến</a>
          <ul>
              <li>
                  <a href=""><i class="fa fa-file-text"></i>Danh Sách Ý kiến</a>
              </li>
              
             
          </ul>
      </li>
  
      <li>
        <a href=""><i class="gi gi-user"></i>Người Dùng</a>
        <ul>
            <li>
                <a href=""><i class="gi gi-user                "></i>Người Dùng</a>
            </li>
            <li>
                <a href=""><i class="gi gi-user_add                "></i>Thêm Người Dùng</a>
            </li>
           
        </ul>
    </li>
  
  
           
        </ul>
    </nav>
    <!-- END Primary Navigation -->
  
    <!-- Demo Theme Options -->
    
    <!-- END Demo Theme Options -->
  </aside>
  
  
  <?php /**PATH C:\xampp\htdocs\Web_Template\resources\views/admin/menu.blade.php ENDPATH**/ ?>