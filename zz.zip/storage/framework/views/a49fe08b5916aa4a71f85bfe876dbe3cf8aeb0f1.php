<section class="bg-home" style="background-image:url('assets/images/home/bg-home.jpg');">
    <div class="bg-overlay"></div>
    <div class="home-center">
        <div class="home-desc-center">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="title-heading text-center">
                            <h1 class="">Financial Planners</h1>
                            <p class="text-white-50 mx-auto">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire.</p>
                            <div class="mt-3">
                                <a href="#" class="btn btn-custom mr-3">Contact Us</a>
                                <a href="#" class="btn btn-outline-white">Learn More</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\Web_Template\resources\views/slide.blade.php ENDPATH**/ ?>