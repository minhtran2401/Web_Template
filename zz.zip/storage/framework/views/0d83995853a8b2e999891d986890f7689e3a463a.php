<?php $__env->startSection("header"); ?>
    <?php echo $__env->make("header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make("menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <?php echo $__env->make("breadrum", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- WORK START -->
<section class="section"> 
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="text-center  btn-buttons btn-outline-dark-gray mr-3 mb-3">
                    <h3 class="mt-4 font-18 font-weight-bold"> TEMPLATE : <?php echo e($title); ?> </h3>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container">
        <div class="port portfolio-masonry mt-3">
            <div class="portfolioContainer row">

                <?php $__currentLoopData = $kq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 part">
                    <div class="portfolio-box">
                        <a class="mfp-image" href="assets/images/work/work-1.jpg" title="Business Post">
                            <img src="<?php echo e($r->image); ?>" class="img-fluid" alt="member-image">
                        </a>
                        <div class="gallary-title text-center">
                            <h6><a href=""><?php echo e($r->name); ?></a></h6>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            
            <?php echo $kq->links(); ?>
        </div>
    </div>
</section>
<!-- WORK END -->

<!-- PARTNER START -->
<section class="section-two bg-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 p-0">
                <div class="slider autoplay">
                    <div><img src="assets/images/client/partner-1.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                    <div><img src="assets/images/client/partner-2.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                    <div><img src="assets/images/client/partner-3.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                    <div><img src="assets/images/client/partner-4.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                    <div><img src="assets/images/client/partner-5.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                    <div><img src="assets/images/client/partner-1.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                    <div><img src="assets/images/client/partner-2.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                    <div><img src="assets/images/client/partner-3.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                    <div><img src="assets/images/client/partner-4.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                    <div><img src="assets/images/client/partner-5.png" class="mx-auto d-block img-fluid" alt="img-missing"></div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- PARTNER END -->
<?php $__env->startSection("footer"); ?>
<?php echo $__env->make("footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Web_Template\resources\views/allcategories.blade.php ENDPATH**/ ?>